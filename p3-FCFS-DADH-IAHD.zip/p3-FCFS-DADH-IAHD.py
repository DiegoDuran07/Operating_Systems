#Programa 3 DADH-IAHD
import process
import tkinter as tk
from tkinter import ttk
from process import *

# Global variables
elapsed_time = 0
is_paused = False
memory_size = 5
pending_tasks = []
main_memory = []
completed_tasks = []
blocked_tasks = []
simulation_started = False
num_tasks = 0

# Paleta de colores
COLOR_BG = "#1e1e1e"  # Fondo oscuro
COLOR_FG = "#ffffff"  # Texto blanco
COLOR_BUTTON_BG = "#333333"  # Fondo de botones
COLOR_BUTTON_FG = "#ffffff"  # Texto de botones
COLOR_TABLE_HEADER = "#444444"  # Encabezados de tablas
COLOR_TABLE_ROW = "#2d2d2d"  # Filas de tablas
COLOR_HIGHLIGHT = "#4CAF50"  # Color de resaltado (verde)

# This function will update the timer's label
def update_time():
    global elapsed_time, blocked_tasks
    if not is_paused:
        elapsed_time += 1
        time_keeper.config(text=f"Tiempo Total Transcurrido: {elapsed_time} s")
        process_memory()

        # Update blocked processes if existent
        if blocked_tasks:
            for process in blocked_tasks:
                process.blockedT -= 1

    if pending_tasks or main_memory or blocked_tasks:
        window.after(1000, update_time)  # Update each second
        update_tables()
    else:
        # When the program has finished its execution the report is generated
        generate_PCB()

# This function will update the remaining tasks label
def update_remaining_tasks():
    global pending_tasks, main_memory
    remaining_tasks.config(text=f"Tareas Restantes: {len(pending_tasks) + len(main_memory)}")

# Function to manage pause and continue functionality
def toggle_pause(event):
    global is_paused
    if event.char.lower() == 'p':
        is_paused = True
    elif event.char.lower() == 'c':
        is_paused = False

# Function to manage interruption events
def interruption(event):
    global main_memory
    if event.char.lower() == 'i' and main_memory and is_paused == False:
        process = main_memory.pop(0)  # Remove the first process (in execution)
        process.blockedT = 7
        process.status = "Bloqueado"
        blocked_tasks.append(process)  # Add it to the end of the in-ready list
        update_tables()  # Update tables to reflect the new state

# Function to manage error events
def error(event):
    global main_memory, completed_tasks
    if event.char.lower() == 'e' and main_memory and is_paused == False:
        process = main_memory.pop(0)  # Remove the first process (in execution)
        completed_tasks.append(process)  # Move it to the completed tasks list
        # BCP Completition
        process.service = process.elapsedT                  # Save the service time
        process.finalization = elapsed_time                 # Save finalization time
        process.ret = max(process.finalization - process.arrive, process.response)  # Ensure ret >= response
        process.wait = process.ret - process.service        # Calculate and save wait time
        process.status = "Completado: Error"

        if pending_tasks:
            new_task = pending_tasks.pop(0)
            if new_task.arrive == -1:
                new_task.arrive = elapsed_time
                new_task.status = "Ready"
            main_memory.append(new_task)
            
        update_remaining_tasks()
        update_tables()  # Update tables to reflect the new state

# Generate PCB report
def generate_PCB():
    global main_memory, completed_tasks, blocked_tasks, elapsed_time

    # Crear una nueva ventana
    PCB_window = tk.Toplevel(window)
    PCB_window.title("Sistemas Operativos: Primero en Llegar, Primero en Servir --- PCB")
    PCB_window.geometry("1200x600")
    PCB_window.configure(bg=COLOR_BG) 

    # Marco principal
    main_frame = tk.Frame(PCB_window, bg=COLOR_BG)
    main_frame.grid(row=0, column=0, padx=5, pady=5, sticky="nsew")

    tk.Label(main_frame, text=":::  Informe PCB  :::", bg=COLOR_BG, fg=COLOR_HIGHLIGHT, font=('Helvetica', 12, 'bold')).grid(row=0, sticky="new")

    # Crear tabla para mostrar los resultados del PCB
    PCB_tree = ttk.Treeview(main_frame, columns=('ID', 'Estado', 'AT', 'FT', 'ST', 'ResT', 'RetT', 'WT'), show='headings', height=10)
    PCB_tree.heading('ID', text='ID')
    PCB_tree.heading('Estado', text='Estado')
    PCB_tree.heading('AT', text='Tiempo de Llegada')
    PCB_tree.heading('FT', text='Tiempo de Finalización')
    PCB_tree.heading('ST', text='Tiempo en Servicio')
    PCB_tree.heading('ResT', text='Tiempo de Respuesta')
    PCB_tree.heading('RetT', text='Tiempo de Retorno')
    PCB_tree.heading('WT', text='Tiempo de Espera')

    PCB_tree.grid(row=1, column=0, padx=5, pady=5, sticky="nsew")

    # Expandir filas y columnas
    PCB_window.grid_rowconfigure(0, weight=1)
    PCB_window.grid_columnconfigure(0, weight=1)

    main_frame.grid_rowconfigure(1, weight=1)
    main_frame.grid_columnconfigure(0, weight=1)

    # Rellenar el informe PCB
    for process in completed_tasks:
        PCB_tree.insert("", tk.END, values=(process.pid, process.status, process.arrive, process.finalization, 
                                            process.service, process.response, process.ret, 
                                            process.wait))
    for process in main_memory:
        # Calcular tiempos estimados
        wait = elapsed_time - process.arrive - process.elapsedT 

        PCB_tree.insert("", tk.END, values=(process.pid, process.status, process.arrive, process.finalization, 
                                            f"{process.elapsedT} *", process.response, process.ret, 
                                            f"{wait} *"))
    for process in blocked_tasks:
        # Calcular tiempos estimados
        wait = elapsed_time - process.arrive - process.elapsedT

        PCB_tree.insert("", tk.END, values=(process.pid, process.status, process.arrive, process.finalization, 
                                            f"{process.elapsedT} *", process.response, process.ret, 
                                            f"{wait} *"))

def process_memory():
    global main_memory, completed_tasks, pending_tasks

    # If there are loaded processes in memory
    if main_memory:
        process = main_memory[0]  # Get the first process
        if process.response == -1:
            if process.pid == 1:
                process.response = 0
            else:
                process.response = elapsed_time - process.arrive
        process.update_time()  # Update its elapsed time
        update_tables()

        # If the process is completed
        if process.remainingT <= 0:
            # BCP Completition
            process.service = process.elapsedT                  # Save the service time
            process.finalization = elapsed_time                 # Save finalization time
            process.ret = max(process.finalization - process.arrive, process.response)  # Ensure ret >= response
            process.wait = process.ret - process.service        # Calculate and save wait time
            process.status = "Completado: Normal"

            completed_tasks.append(main_memory.pop(0))  # Move it to completed tasks
            
            if pending_tasks:  # If there are pending tasks
                process = pending_tasks.pop(0)
                # Save arrival time to the memory
                if process.arrive == -1:
                    process.arrive = elapsed_time
                    process.status = "Ready"
                main_memory.append(process)
            update_remaining_tasks()
            update_tables()

def update_tables():
    # Update Ready Table
    for row in ready_tree.get_children():
        ready_tree.delete(row)
    for process in main_memory[1:]:
        ready_tree.insert("", tk.END, values=(process.pid, process.maxT, process.elapsedT))
    
    # Update In Process Table
    for row in process_tree.get_children():
        process_tree.delete(row)
    if main_memory:
        process = main_memory[0]
        process.status = "En proceso"
        process_tree.insert("", tk.END, values=(process.pid, process.maxT, process.elapsedT, process.remainingT, process.op))
    
    # Update Blocked Process Table
    for row in blocked_tree.get_children():
        blocked_tree.delete(row)
    for process in blocked_tasks:
        if process.blockedT >= 0:
            blocked_tree.insert("", tk.END, values=(process.pid, process.maxT, process.elapsedT, process.blockedT))
        else: 
            process.status = "Listo"
            main_memory.append(process)
            blocked_tasks.remove(process)

    # Update Completed Tasks Table
    for row in completed_tree.get_children():
        completed_tree.delete(row)
    for process in completed_tasks:
        process.solve()
        if process.maxT != process.elapsedT:
            completed_tree.insert("", tk.END, values=(process.pid, process.op, "Error"))
        elif process.maxT == process.elapsedT:
            completed_tree.insert("", tk.END, values=(process.pid, process.op, process.result))

def start_simulation():
    global pending_tasks, main_memory, simulation_started, num_tasks
    
    if simulation_started:
        return  # Exit the function if the simulation has already started
    
    # Get the number of tasks from the input field
    try:
        num_tasks = int(task_entry.get())
        if num_tasks <= 0:
            raise ValueError("Number of tasks must be greater than 0.")
    except ValueError as e:
        print(f"Entrada invalida: {e}")
        return

    # Generate processes
    pending_tasks = generate_processes(num_tasks)
    update_remaining_tasks()
    main_memory = pending_tasks[:memory_size]
    for task in main_memory:
        task.arrive = elapsed_time
    pending_tasks = pending_tasks[memory_size:]
    
    # Update tables
    update_tables()

    # Disable the start button and entry field after the first use
    start_button.config(state=tk.DISABLED)
    task_entry.config(state=tk.DISABLED)
    
    # Set the flag to true
    simulation_started = True
    
    # Start the timer
    update_time()

''' Configuración General de la Ventana Principal
'''
window = tk.Tk()
window.title("Sistemas Operativos: First Come First Served   DADH-IAHD")
window.geometry("1200x700")  # Ajusté el tamaño de la ventana
window.configure(bg=COLOR_BG)

# Asignar las teclas P y C a la función toggle_pause
window.bind("<Key>", toggle_pause)
window.bind("<Key-i>", interruption)
window.bind("<Key-e>", error)   

''' Configuración General de los Frames
'''
# Frame de control
control_frame = tk.Frame(window, bg=COLOR_BG)
control_frame.grid(row=0, column=0, columnspan=3, padx=10, pady=10, sticky="nsew")

# Frame para tareas listas
ready_frame = tk.Frame(window, bg=COLOR_BG)
ready_frame.grid(row=1, column=0, padx=10, pady=10, sticky="nsew")

# Frame para tareas en proceso
process_frame = tk.Frame(window, bg=COLOR_BG)
process_frame.grid(row=1, column=1, padx=10, pady=10, sticky="nsew")

# Frame para tareas completadas
completed_frame = tk.Frame(window, bg=COLOR_BG)
completed_frame.grid(row=1, column=2, padx=10, pady=10, sticky="nsew")

# Panel de Control Configuración
tk.Label(control_frame, text=":::  P - Pausa  :::  C - Continuar  :::  I - Interrupción  :::  E - Error  :::", 
         bg=COLOR_BG, fg=COLOR_HIGHLIGHT, font=('Helvetica', 12, 'bold')).grid(row=0, column=0, columnspan=3, padx=10, pady=5, sticky="w")
remaining_tasks = tk.Label(control_frame, text="Tareas Restantes: ", bg=COLOR_BG, fg=COLOR_FG, font=('Helvetica', 10))
remaining_tasks.grid(row=1, column=0, padx=10, pady=5, sticky="w")
time_keeper = tk.Label(control_frame, text="Tiempo Total Transcurrido: 0 s", bg=COLOR_BG, fg=COLOR_FG, font=('Helvetica', 10))
time_keeper.grid(row=2, column=0, padx=10, pady=5, sticky="w")
tk.Label(control_frame, text="Total de Tareas: ", bg=COLOR_BG, fg=COLOR_FG, font=('Helvetica', 10)).grid(row=3, column=0, padx=10, pady=5, sticky="w")

# Entrada de tareas y botón de inicio
task_entry = tk.Entry(control_frame, width=15, bg=COLOR_BUTTON_BG, fg=COLOR_FG, font=('Helvetica', 10))
task_entry.grid(row=3, column=1, padx=5, pady=5)
start_button = tk.Button(control_frame, text="Iniciar", bg=COLOR_BUTTON_BG, fg=COLOR_FG, relief="flat", overrelief="flat", command=start_simulation, font=('Helvetica', 10))
start_button.grid(row=3, column=2, padx=10, pady=5)

# Panel de Tareas Listas Configuración
tk.Label(ready_frame, text=":::  Listo  :::", bg=COLOR_BG, fg=COLOR_HIGHLIGHT, font=('Helvetica', 12, 'bold')).grid(row=0, column=0, sticky="ew")
ready_tree = ttk.Treeview(ready_frame, columns=('ID', 'TM', 'TE'), show='headings', height=10)
ready_tree.heading('ID', text='ID')
ready_tree.heading('TM', text='Tiempo Máximo')
ready_tree.heading('TE', text='Tiempo Transcurrido')
ready_tree.grid(row=1, padx=5, pady=5, sticky="nsew")

# Panel de Tareas en Proceso Configuración
tk.Label(process_frame, text=":::  Proceso en ejecución  :::", bg=COLOR_BG, fg=COLOR_HIGHLIGHT, font=('Helvetica', 12, 'bold')).grid(row=0, sticky="new")
process_tree = ttk.Treeview(process_frame, columns=('ID', 'TM', 'TE', 'TR', 'OP'), show='headings', height=10)
process_tree.heading('ID', text='ID')
process_tree.heading('TM', text='Tiempo Máximo')
process_tree.heading('TE', text='Tiempo Transcurrido')
process_tree.heading('TR', text='Tiempo Restante')
process_tree.heading('OP', text='Operación')
process_tree.grid(row=1, padx=5, pady=5, sticky="nsew")

# Panel de Tareas Bloqueadas Configuración
tk.Label(process_frame, text=":::  Procesos Bloqueados  :::", bg=COLOR_BG, fg=COLOR_HIGHLIGHT, font=('Helvetica', 12, 'bold')).grid(row=2, sticky="new")
blocked_tree = ttk.Treeview(process_frame, columns=('ID', 'TM', 'TE', 'TBR'), show='headings', height=10)
blocked_tree.heading('ID', text='ID')
blocked_tree.heading('TM', text='Tiempo Máximo')
blocked_tree.heading('TE', text='Tiempo Transcurrido')
blocked_tree.heading('TBR', text='Tiempo Restante Bloqueado')
blocked_tree.grid(row=3, padx=5, pady=5, sticky="nsew")

# Panel de Tareas Completadas Configuración
tk.Label(completed_frame, text=":::  Procesos Terminados  :::", bg=COLOR_BG, fg=COLOR_HIGHLIGHT, font=('Helvetica', 12, 'bold')).grid(row=0, sticky="ew")
completed_tree = ttk.Treeview(completed_frame, columns=('ID', 'OP', 'RES'), show='headings', height=10)
completed_tree.heading('ID', text='ID')
completed_tree.heading('OP', text='Operación')
completed_tree.heading('RES', text='Resultado')
completed_tree.grid(row=1, padx=5, pady=5, sticky="nsew")

# Expandir filas y columnas
window.grid_rowconfigure(0, weight=1)
window.grid_columnconfigure(0, weight=1)
window.grid_columnconfigure(1, weight=1)
window.grid_columnconfigure(2, weight=1)

ready_frame.grid_rowconfigure(1, weight=1)
ready_frame.grid_columnconfigure(0, weight=1)
process_frame.grid_rowconfigure(1, weight=1)
process_frame.grid_columnconfigure(0, weight=1)
completed_frame.grid_rowconfigure(1, weight=1)
completed_frame.grid_columnconfigure(0, weight=1)

# Bucle principal
window.mainloop()