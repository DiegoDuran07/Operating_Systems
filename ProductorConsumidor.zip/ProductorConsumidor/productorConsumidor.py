import tkinter as tk
import threading
import listaCircularLigada as LCL
import random
import time
from tkinter import ttk
from threading import Semaphore


# Constants
BOX_AMOUNT=20
BOX_WIDTH=40
BOX_HEIGHT=40
MIN_SLEEP_TIME=1
MAX_SLEEP_TIME=5
MAX_OBJ_AMOUNT=20
MIN_OBJ=3
MAX_OBJ=6
OBJ='XD'
NO_OBJ='_'

# Main window setup
window=tk.Tk()
WINDOW_WIDTH=window.winfo_screenwidth()
WINDOW_HEIGHT=window.winfo_screenheight()
window.title("Productor-Consumidor")
window.geometry(f'{WINDOW_WIDTH}x{WINDOW_HEIGHT}')
#window.resizable(False, False)
window.grid_rowconfigure(0, minsize=(WINDOW_HEIGHT-(BOX_HEIGHT*2))/2)
window.grid_rowconfigure(1, minsize=BOX_HEIGHT*2)
window.grid_rowconfigure(2, minsize=(WINDOW_HEIGHT-(BOX_HEIGHT*2))/2)
window.grid_columnconfigure(0, minsize=(WINDOW_WIDTH-(BOX_WIDTH*BOX_AMOUNT))/2)
window.grid_columnconfigure(1, minsize=BOX_WIDTH*BOX_AMOUNT)
window.grid_columnconfigure(2, minsize=(WINDOW_WIDTH-(BOX_WIDTH*BOX_AMOUNT))/2)


def closeWindow(e):
    window.destroy()

window.bind('<Escape>', lambda e: closeWindow(e))

# Global variables declaration
global producerStateVar
global consumerStateVar
global boxesLabels
global boxesLabelsVars

# Global variables definition
producerStateVar=tk.StringVar(value='NULL')
consumerStateVar=tk.StringVar(value='NULL')
mutex=Semaphore(1)
boxesLabels=[]
boxesLabelsVars=[]

def produce():
    global producerStateVar
    lastBox=0
    while True:
        # Sleeping
        producerStateVar.set('Productor: durmiendo')
        print(producerStateVar.get())

        # Calculating and waiting the sleep time
        sleepTime=random.randint(MIN_SLEEP_TIME, MAX_SLEEP_TIME)
        time.sleep(sleepTime)
        
        # Waking up ready to produce 'objAmount' of objects
        objAmount=random.randint(MIN_OBJ, MAX_OBJ)
        producerStateVar.set(f'Productor: listo para producir {objAmount} objetos')
        print(producerStateVar.get())

        # Checking if there is enough space in buffer, if not, waiting one second before checking once again
        while (MAX_OBJ_AMOUNT-buffer.getAmount()) < objAmount:
            time.sleep(1)

        # Trying to enter the buffer
        mutex.acquire()
        
        # Once in the buffer, producing one object every second
        producerStateVar.set(f'Productor: produciendo {objAmount} objetos')
        print(producerStateVar.get())
        for i in range(objAmount):

            # Circular queue logic
            if lastBox==MAX_OBJ_AMOUNT:
                lastBox=0

            buffer.update(OBJ, lastBox)
            boxesLabelsVars[lastBox].set(OBJ)
            lastBox+=1
            time.sleep(1)

        # Exiting the buffer
        mutex.release()

def consume():
    global consumerStateVar
    lastBox=0
    while True:
        # Sleeping
        consumerStateVar.set('Consumidor: durmiendo')
        print(consumerStateVar.get())

        # Calculating and waiting the sleep time
        sleepTime=random.randint(MIN_SLEEP_TIME, MAX_SLEEP_TIME)
        time.sleep(sleepTime)
        
        # Waking up ready to consume 'objAmount' of objects
        objAmount=random.randint(MIN_OBJ, MAX_OBJ)
        consumerStateVar.set(f'Consumidor: listo para consumir {objAmount} objetos')
        print(consumerStateVar.get())

        # Checking if there is enough objects in buffer, if not, waiting one second before checking once again
        while buffer.getAmount() < objAmount:
            time.sleep(1)

        # Once ending waiting for something to consume, trying to enter the buffer
        mutex.acquire()
        
        # Once in the buffer, consuming one object every second
        consumerStateVar.set(f'Consumidor: consumiendo {objAmount} objetos')
        print(consumerStateVar.get())
        for i in range(objAmount):

            # Circular queue logic
            if lastBox==MAX_OBJ_AMOUNT:
                lastBox=0

            buffer.update(NO_OBJ, lastBox)
            boxesLabelsVars[lastBox].set(NO_OBJ)
            lastBox+=1
            time.sleep(1)

        # Exiting the buffer
        mutex.release()

# Initializing the buffer
buffer=LCL.CircularLinkedList()
for i in range(MAX_OBJ_AMOUNT):
    buffer.insert_at_end("_")

# Creating the threads for Producer and Consumer
threadPro=threading.Thread(target=produce)
threadCon=threading.Thread(target=consume)

# Widget setup
bufferFrame=ttk.Frame(window, width=BOX_WIDTH*BOX_AMOUNT, height=BOX_HEIGHT*2)
bufferFrame.grid(row=1, column=1)

for i in range(BOX_AMOUNT):
    boxFrame=ttk.Frame(bufferFrame, borderwidth=1, relief='sunken', width=BOX_WIDTH, height=BOX_HEIGHT)
    boxFrame.grid_propagate(False)
    boxFrame.grid(row=0, column=i)

    boxLabelVar=tk.StringVar(value="_")
    boxesLabelsVars.append(boxLabelVar)

    boxLabel=ttk.Label(boxFrame, text=boxLabelVar.get(), textvariable=boxLabelVar)
    boxLabel.grid(row=0, column=0)
    boxesLabels.append(boxLabel)


    boxEnumFrame=ttk.Frame(bufferFrame, width=BOX_WIDTH, height=BOX_HEIGHT)
    boxEnumFrame.grid_propagate(False)
    boxEnumFrame.grid(row=1, column=i)

    boxEnumLabel=ttk.Label(boxEnumFrame, text=i+1, anchor='center')
    boxEnumLabel.grid(row=0, column=0)

producerFrame=ttk.Frame(window, borderwidth=1, relief='sunken')
producerFrame.grid(row=2, column=0)
labelProducer=ttk.Label(producerFrame, text=producerStateVar.get(), textvariable=producerStateVar)
labelProducer.pack()

consumerFrame=ttk.Frame(window, borderwidth=1, relief='sunken')
consumerFrame.grid(row=2, column=2)
labelConsumer=ttk.Label(consumerFrame, text=consumerStateVar.get(), textvariable=consumerStateVar)
labelConsumer.pack()

titleLabel=ttk.Label(window, text='Productor-Consumidor', font=("Helvetica", 20))
titleLabel.grid(row=0, column=1)

# Starting both threads
threadPro.start()
threadCon.start()

# Main window run
window.mainloop()