class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class CircularLinkedList:
    def __init__(self):
        self.head = None

    def insert_at_beginning(self, data):
        new_node = Node(data)
        if self.head is None:
            self.head = new_node
            new_node.next = self.head
        else:
            curr = self.head
            while curr.next != self.head:
                curr = curr.next
            curr.next = new_node
            new_node.next = self.head
            self.head = new_node

    def insert_at_end(self, data):
        new_node = Node(data)
        if self.head is None:
            self.head = new_node
            new_node.next = self.head
        else:
            curr = self.head
            while curr.next != self.head:
                curr = curr.next
            curr.next = new_node
            new_node.next = self.head

    def insert_at_position(self, data, position):
        if position < 0:
            print("Posición inválida")
            return
        elif position == 0:
            self.insert_at_beginning(data)
        else:
            new_node = Node(data)
            curr = self.head
            count = 0
            while count < position - 1 and curr.next != self.head:
                curr = curr.next
                count += 1
            if count == position - 1:
                new_node.next = curr.next
                curr.next = new_node
            else:
                print("Posición fuera de rango")

    def update(self, data, position):
        if position < 0:
            print("Posición inválida")
            return
        else:
            count = 0
            curr = self.head
            while count <= position-1:
                curr=curr.next
                count+=1
            curr.data=data

    def delete(self, data):
        if self.head is None:
            print("La lista está vacia")
            return
        if self.head.data == data:
            if self.head.next == self.head:
                self.head = None
            else:
                curr = self.head
                while curr.next != self.head:
                    curr = curr.next
                curr.next = self.head.next
                self.head = self.head.next
            return
        curr = self.head
        prev = None
        while curr.next != self.head:
            if curr.data == data:
                prev.next = curr.next
                return
            prev = curr
            curr = curr.next
        if curr.data == data:
            prev.next = curr.next
        else:
            print("No se encontró el elemento")

    def traverse(self):
        if self.head is None:
            print("La lista está vacia")
            return
        curr = self.head
        while True:
            print(curr.data, end=" ")
            curr = curr.next
            if curr == self.head:
                break
        print()

    def search(self, data):
        if self.head is None:
            print("La lista está vacia")
            return False
        curr = self.head
        while True:
            if curr.data == data:
                return True
            curr = curr.next
            if curr == self.head:
                break
        return False

    def isEmpty(self):
        isEmpty = True
        curr = self.head
        while curr.next != self.head:
            if curr.data != '_':
                isEmpty = False
                break
            curr=curr.next
        return isEmpty

    def isFull(self):
        isFull = True
        curr = self.head
        while curr.next != self.head:
            if curr.data == '_':
                isFull = False
                break
            curr=curr.next
        return isFull;

    def getAmount(self):
        count = 0
        curr = self.head
        while curr.next != self.head:
            if curr.data != '_':
                count+=1
            curr=curr.next
        if curr.data != '_':
            count+=1
        return count


if __name__ == "__main__:":
    # Testing the Circular Linked List
    cll = CircularLinkedList()
    cll.insert_at_beginning(10)
    cll.insert_at_beginning(20)
    cll.insert_at_end(30)
    cll.insert_at_end(40)
    cll.insert_at_position(50, 2)

    print("Circular Linked List:")
    cll.traverse()

    print("Is 30 present in the list?", cll.search(30))
    print("Is 100 present in the list?", cll.search(100))

    cll.delete(30)
    cll.delete(20)

    print("Updated Circular Linked List:")
    cll.traverse()