
# Programa 3 DADH-IAHD - Interfaz Moderna Gris/Verde
import processFCFS
import tkinter as tk
from tkinter import ttk
from processFCFS import *

# Paleta de colores
DARK_GRAY = "#252525"
MEDIUM_GRAY = "#2f2f2f"
LIGHT_GRAY = "#3a3a3a"
ACCENT_GREEN = "#2ecc71"
WHITE = "#ffffff"
BLACK = "#000000"

# Global variables
elapsed_time = 0
is_paused = False
memory_size = 5
pending_tasks = []
main_memory = []
completed_tasks = []
blocked_tasks = []
simulation_started = False 
num_tasks = 0

# Función para actualizar el temporizador
def update_time():
    global elapsed_time, blocked_tasks
    if not is_paused:
        elapsed_time += 1
        time_keeper.config(text=f"Tiempo Total Transcurrido: {elapsed_time} s")
        process_memory()

        # Actualizar procesos bloqueados si existen
        if blocked_tasks:
            for process in blocked_tasks:
                process.blockedT -= 1

    if pending_tasks or main_memory or blocked_tasks:
        window.after(1000, update_time)  # Actualizar cada segundo
        update_tables()
    else:
        # Generar reporte cuando finaliza la ejecución
        generate_PCB()

# Actualizar contador de tareas restantes
def update_remaining_tasks():
    global pending_tasks, main_memory
    remaining_tasks.config(text=f"Tareas Restantes: {len(pending_tasks) + len(main_memory)}")

# Función para pausar/continuar
def toggle_pause(event):
    global is_paused
    if event.char.lower() == 'p':
        is_paused = True
        pause_label.config(text="Estado: PAUSADO", fg="#e74c3c")
    elif event.char.lower() == 'c':
        is_paused = False
        pause_label.config(text="Estado: EJECUTANDO", fg=ACCENT_GREEN)

# Función para manejar interrupciones
def interruption(event):
    global main_memory
    if event.char.lower() == 'i' and main_memory and is_paused == False:
        process = main_memory.pop(0)  # Remover primer proceso (en ejecución)
        process.blockedT = 7
        process.status = "Bloqueado"
        blocked_tasks.append(process)  # Agregar a lista de bloqueados
        update_tables()  # Actualizar tablas

# Función para manejar errores
def error(event):
    global main_memory, completed_tasks
    if event.char.lower() == 'e' and main_memory and is_paused == False:
        process = main_memory.pop(0)  # Remover primer proceso (en ejecución)
        completed_tasks.append(process)  # Mover a tareas completadas
        
        # Actualizar BCP
        process.service = process.elapsedT                  
        process.finalization = elapsed_time                 
        process.ret = process.finalization - process.arrive 
        process.wait = process.ret - process.service        
        process.status = "Completado: Error"

        if pending_tasks:
            new_task = pending_tasks.pop(0)
            if new_task.arrive == -1:
                new_task.arrive = elapsed_time
                new_task.status = "Ready"
            main_memory.append(new_task)
            
        update_remaining_tasks()
        update_tables()

# Generar nuevo proceso
def new_process(event):
    global main_memory, is_paused, pending_tasks, num_tasks, blocked_tasks
    if event.char.lower() == 'n' and (main_memory or blocked_tasks) and is_paused == False:
        num_tasks += 1
        new_task = generate_processes(1)[0]
        new_task.pid = num_tasks

        # Si hay espacio en memoria principal, agregarlo directamente
        if (len(main_memory) + len(blocked_tasks)) < 5:
            new_task.arrive = elapsed_time
            new_task.status = "Ready"
            main_memory.append(new_task)   
        else: 
            # Si no hay espacio, agregar a lista de espera
            pending_tasks.append(new_task)  

        update_remaining_tasks()

# Ver BCP durante ejecución
def view_PCB(event):
    global main_memory, blocked_tasks, is_paused
    if event.char.lower() == 'b' and (main_memory or blocked_tasks) and not is_paused:
        is_paused = True
        pause_label.config(text="Estado: PAUSADO", fg="#e74c3c")
        generate_PCB()

# Generar reporte PCB
def generate_PCB():
    global main_memory, completed_tasks, blocked_tasks, elapsed_time

    # Crear nueva ventana
    PCB_window = tk.Toplevel(window)
    PCB_window.title("Sistemas Operativos: FCFS - Reporte PCB")
    PCB_window.geometry("1200x600")
    PCB_window.configure(bg=DARK_GRAY) 

    # Marco principal
    main_frame = tk.Frame(PCB_window, bg=MEDIUM_GRAY, padx=10, pady=10)
    main_frame.pack(fill=tk.BOTH, expand=True)

    # Título
    title_frame = tk.Frame(main_frame, bg=MEDIUM_GRAY)
    title_frame.pack(fill=tk.X)
    tk.Label(title_frame, text=":::  Informe PCB  :::", bg=MEDIUM_GRAY, fg=ACCENT_GREEN, 
             font=('Helvetica', 12, 'bold')).pack(pady=10)

    # Crear tabla PCB
    style = ttk.Style()
    style.configure("PCB.Treeview", background=LIGHT_GRAY, fieldbackground=LIGHT_GRAY, 
                    foreground=WHITE, font=('Helvetica', 10))
    style.configure("PCB.Treeview.Heading", background=ACCENT_GREEN, foreground=BLACK, 
                    font=('Helvetica', 10, 'bold'))
    style.map("PCB.Treeview", background=[('selected', '#3498db')])

    PCB_tree = ttk.Treeview(main_frame, style="PCB.Treeview", 
                           columns=('ID', 'Estado', 'AT', 'FT', 'ST', 'ResT', 'RetT', 'WT'), 
                           show='headings', height=10)
    
    # Configurar columnas
    columns = {
        'ID': {'text': 'ID', 'width': 80},
        'Estado': {'text': 'Estado', 'width': 120},
        'AT': {'text': 'Tiempo de Llegada', 'width': 120},
        'FT': {'text': 'Tiempo de Finalización', 'width': 140},
        'ST': {'text': 'Tiempo en Servicio', 'width': 120},
        'ResT': {'text': 'Tiempo de Respuesta', 'width': 130},
        'RetT': {'text': 'Tiempo de Retorno', 'width': 120},
        'WT': {'text': 'Tiempo de Espera', 'width': 120}
    }
    
    for col, config in columns.items():
        PCB_tree.heading(col, text=config['text'])
        PCB_tree.column(col, width=config['width'], anchor="center")

    # Scrollbar
    scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=PCB_tree.yview)
    PCB_tree.configure(yscrollcommand=scrollbar.set)
    scrollbar.pack(side="right", fill="y")
    PCB_tree.pack(fill=tk.BOTH, expand=True)

    # Notas
    notes_frame = tk.Frame(main_frame, bg=MEDIUM_GRAY)
    notes_frame.pack(fill=tk.X, pady=10)
    tk.Label(notes_frame, text="'*' Valor podría variar en el futuro cercano.", 
             bg=MEDIUM_GRAY, fg=ACCENT_GREEN).pack(side="left", padx=10)
    tk.Label(notes_frame, text="'-1' No se puede calcular en este momento.", 
             bg=MEDIUM_GRAY, fg=ACCENT_GREEN).pack(side="left", padx=10)

    # Rellenar tabla PCB
    for process in completed_tasks:
        PCB_tree.insert("", tk.END, values=(process.pid, process.status, process.arrive, process.finalization, 
                                          process.service, process.response, process.ret, 
                                          process.wait))
    for process in main_memory:
        wait = elapsed_time - process.arrive - process.elapsedT 
        PCB_tree.insert("", tk.END, values=(process.pid, process.status, process.arrive, process.finalization, 
                                          f"{process.elapsedT} *", process.response, process.ret, 
                                          f"{wait} *"))
    for process in blocked_tasks:
        wait = elapsed_time - process.arrive - process.elapsedT
        PCB_tree.insert("", tk.END, values=(process.pid, process.status, process.arrive, process.finalization, 
                                          f"{process.elapsedT} *", process.response, process.ret, 
                                          f"{wait} *"))

def process_memory():
    global main_memory, completed_tasks, pending_tasks

    if main_memory:
        process = main_memory[0]  # Obtener primer proceso
        if process.response == -1:
            if process.pid == 1:
                process.response = 0
            else:
                process.response = elapsed_time - process.arrive
        process.update_time()  # Actualizar tiempo transcurrido
        update_tables()

        # Si el proceso está completado
        if process.remainingT <= 0:
            # Actualizar BCP
            process.service = process.elapsedT                  
            process.finalization = elapsed_time                 
            process.ret = process.finalization - process.arrive 
            process.wait = process.ret - process.service        
            process.status = "Completado: Normal"

            completed_tasks.append(main_memory.pop(0))  # Mover a completados
            
            if pending_tasks:  # Si hay tareas pendientes
                process = pending_tasks.pop(0)
                if process.arrive == -1:
                    process.arrive = elapsed_time
                    process.status = "Ready"
                main_memory.append(process)
            update_remaining_tasks()
            update_tables()

def update_tables():
    # Actualizar tabla de listos
    for row in ready_tree.get_children():
        ready_tree.delete(row)
    for process in main_memory[1:]:
        ready_tree.insert("", tk.END, values=(process.pid, process.maxT, process.elapsedT))
    
    # Actualizar tabla de proceso en ejecución
    for row in process_tree.get_children():
        process_tree.delete(row)
    if main_memory:
        process = main_memory[0]
        process.status = "En proceso"
        process_tree.insert("", tk.END, values=(process.pid, process.maxT, process.elapsedT, process.remainingT, process.op))
    
    # Actualizar tabla de bloqueados
    for row in blocked_tree.get_children():
        blocked_tree.delete(row)
    for process in blocked_tasks:
        if process.blockedT >= 0:
            blocked_tree.insert("", tk.END, values=(process.pid, process.maxT, process.elapsedT, process.blockedT))
        else: 
            process.status = "Listo"
            main_memory.append(process)
            blocked_tasks.remove(process)

    # Actualizar tabla de completados
    for row in completed_tree.get_children():
        completed_tree.delete(row)
    for process in completed_tasks:
        process.solve()
        if process.maxT != process.elapsedT:
            completed_tree.insert("", tk.END, values=(process.pid, process.op, "Error"))
        elif process.maxT == process.elapsedT:
            completed_tree.insert("", tk.END, values=(process.pid, process.op, process.result))

def start_simulation():
    global pending_tasks, main_memory, simulation_started, num_tasks
    
    if simulation_started:
        return  # Salir si la simulación ya comenzó
    
    try:
        num_tasks = int(task_entry.get())
        if num_tasks <= 0:
            raise ValueError("Número de tareas debe ser mayor que 0.")
    except ValueError as e:
        print(f"Entrada inválida: {e}")
        return

    # Generar procesos
    pending_tasks = generate_processes(num_tasks)
    update_remaining_tasks()
    main_memory = pending_tasks[:memory_size]
    for task in main_memory:
        task.arrive = elapsed_time
    pending_tasks = pending_tasks[memory_size:]
    
    update_tables()

    # Deshabilitar botón de inicio después de usarlo
    start_button.config(state=tk.DISABLED)
    task_entry.config(state=tk.DISABLED)
    
    simulation_started = True
    pause_label.config(text="Estado: EJECUTANDO", fg=ACCENT_GREEN)
    update_time()

''' Configuración de la Ventana Principal '''
window = tk.Tk()
window.title("Sistemas Operativos: First Come First Served")
window.geometry("1100x650")
window.configure(bg=DARK_GRAY)

# Configurar eventos de teclado
window.bind("<Key>", toggle_pause)
window.bind("<Key-i>", interruption)
window.bind("<Key-e>", error)  
window.bind("<Key-n>", new_process)
window.bind("<Key-b>", view_PCB)   

''' Estilos Personalizados '''
style = ttk.Style()
style.theme_use('clam')

# Configurar estilos para Treeview
style.configure("Treeview", 
               background=LIGHT_GRAY, 
               foreground=WHITE,
               fieldbackground=LIGHT_GRAY,
               font=('Helvetica', 9))
style.configure("Treeview.Heading", 
               background=ACCENT_GREEN,
               foreground=BLACK,
               font=('Helvetica', 10, 'bold'))
style.map("Treeview", background=[('selected', '#3498db')])

# Configurar estilo para botones
style.configure("TButton", 
               background=ACCENT_GREEN,
               foreground=BLACK,
               font=('Helvetica', 10),
               borderwidth=1)
style.map("TButton", 
         background=[('active', '#27ae60')])

# Configurar estilo para Entry
style.configure("TEntry", 
               fieldbackground=LIGHT_GRAY,
               foreground=WHITE,
               insertcolor=WHITE,
               borderwidth=1)

''' Configuración de los Frames '''
# Frame de Control Superior
control_frame = tk.Frame(window, bg=MEDIUM_GRAY, padx=10, pady=10)
control_frame.grid(row=0, column=0, columnspan=3, sticky="nsew", padx=5, pady=5)

# Frames para las tablas
ready_frame = tk.Frame(window, bg=MEDIUM_GRAY, padx=5, pady=5)
ready_frame.grid(row=1, column=0, sticky="nsew", padx=5, pady=5)

completed_frame = tk.Frame(window, bg=MEDIUM_GRAY, padx=5, pady=5)
completed_frame.grid(row=1, column=1, sticky="nsew", padx=5, pady=5)

process_frame = tk.Frame(window, bg=MEDIUM_GRAY, padx=5, pady=5)
process_frame.grid(row=1, column=2, sticky="nsew", padx=5, pady=5)

''' Controles Superiores '''
# Barra de controles
controls_label = tk.Label(control_frame, 
                         text=":::  P - Pausa  :::  C - Continuar  :::  I - Interrupción  :::  E - Error  :::  N - Nuevo Proceso  :::  B - Estado de BCP  :::", 
                         bg=MEDIUM_GRAY, fg=ACCENT_GREEN, font=('Helvetica', 10, 'bold'))
controls_label.pack(side="top", fill="x", pady=5)

# Estado de simulación
pause_label = tk.Label(control_frame, text="Estado: NO INICIADO", bg=MEDIUM_GRAY, fg="#e74c3c", font=('Helvetica', 10, 'bold'))
pause_label.pack(side="top", anchor="w", pady=5)

# Contadores
info_frame = tk.Frame(control_frame, bg=MEDIUM_GRAY)
info_frame.pack(side="top", fill="x", pady=5)

time_keeper = tk.Label(info_frame, text="Tiempo Total Transcurrido: 0 s", bg=MEDIUM_GRAY, fg=WHITE)
time_keeper.pack(side="left", padx=10)

remaining_tasks = tk.Label(info_frame, text="Tareas Restantes: 0", bg=MEDIUM_GRAY, fg=WHITE)
remaining_tasks.pack(side="left", padx=10)

# Entrada para número de tareas
input_frame = tk.Frame(control_frame, bg=MEDIUM_GRAY)
input_frame.pack(side="top", fill="x", pady=5)

tk.Label(input_frame, text="Total de Tareas:", bg=MEDIUM_GRAY, fg=WHITE).pack(side="left", padx=5)
task_entry = ttk.Entry(input_frame, width=15)
task_entry.pack(side="left", padx=5)

start_button = ttk.Button(input_frame, text="Iniciar Simulación", command=start_simulation)
start_button.pack(side="left", padx=10)

''' Configuración de las Tablas '''
# Tabla de Procesos Listos
tk.Label(ready_frame, text=":::  Listo  :::", bg=MEDIUM_GRAY, fg=ACCENT_GREEN, 
         font=('Helvetica', 10, 'bold')).pack(side="top", fill="x")

ready_tree = ttk.Treeview(ready_frame, columns=('ID', 'TM', 'TE'), show='headings', height=8)
ready_tree.heading('ID', text='ID')
ready_tree.heading('TM', text='Tiempo Máximo')
ready_tree.heading('TE', text='Tiempo Transcurrido')

ready_tree.column('ID', width=80, anchor="center")
ready_tree.column('TM', width=120, anchor="center")
ready_tree.column('TE', width=120, anchor="center")

ready_tree.pack(fill="both", expand=True, padx=5, pady=5)

# Tabla de Proceso en Ejecución
tk.Label(process_frame, text=":::  Proceso en ejecución  :::", bg=MEDIUM_GRAY, fg=ACCENT_GREEN, 
         font=('Helvetica', 10, 'bold')).pack(side="top", fill="x")

process_tree = ttk.Treeview(process_frame, columns=('ID', 'TM', 'TE', 'TR', 'OP'), show='headings', height=4)
process_tree.heading('ID', text='ID')
process_tree.heading('TM', text='Tiempo Máximo')
process_tree.heading('TE', text='Tiempo Transcurrido')
process_tree.heading('TR', text='Tiempo Restante')
process_tree.heading('OP', text='Operación')

process_tree.column('ID', width=80, anchor="center")
process_tree.column('TM', width=100, anchor="center")
process_tree.column('TE', width=100, anchor="center")
process_tree.column('TR', width=100, anchor="center")
process_tree.column('OP', width=150, anchor="center")

process_tree.pack(fill="both", expand=True, padx=5, pady=5)

# Tabla de Procesos Bloqueados
tk.Label(process_frame, text=":::  Procesos Bloqueados  :::", bg=MEDIUM_GRAY, fg=ACCENT_GREEN, 
         font=('Helvetica', 10, 'bold')).pack(side="top", fill="x")

blocked_tree = ttk.Treeview(process_frame, columns=('ID', 'TM', 'TE', 'TBR'), show='headings', height=4)
blocked_tree.heading('ID', text='ID')
blocked_tree.heading('TM', text='Tiempo Máximo')
blocked_tree.heading('TE', text='Tiempo Transcurrido')
blocked_tree.heading('TBR', text='Tiempo Restante Bloqueado')

blocked_tree.column('ID', width=80, anchor="center")
blocked_tree.column('TM', width=100, anchor="center")
blocked_tree.column('TE', width=100, anchor="center")
blocked_tree.column('TBR', width=150, anchor="center")

blocked_tree.pack(fill="both", expand=True, padx=5, pady=5)

# Tabla de Procesos Completados
tk.Label(completed_frame, text=":::  Procesos Terminados  :::", bg=MEDIUM_GRAY, fg=ACCENT_GREEN, 
         font=('Helvetica', 10, 'bold')).pack(side="top", fill="x")

completed_tree = ttk.Treeview(completed_frame, columns=('ID', 'OP', 'RES'), show='headings', height=8)
completed_tree.heading('ID', text='ID')
completed_tree.heading('OP', text='Operación')
completed_tree.heading('RES', text='Resultado')

completed_tree.column('ID', width=80, anchor="center")
completed_tree.column('OP', width=200, anchor="center")
completed_tree.column('RES', width=200, anchor="center")

completed_tree.pack(fill="both", expand=True, padx=5, pady=5)

''' Configuración del Grid '''
window.grid_rowconfigure(1, weight=1)
window.grid_columnconfigure(0, weight=1)
window.grid_columnconfigure(1, weight=1)
window.grid_columnconfigure(2, weight=1)

ready_frame.grid_rowconfigure(0, weight=1)
ready_frame.grid_columnconfigure(0, weight=1)

completed_frame.grid_rowconfigure(0, weight=1)
completed_frame.grid_columnconfigure(0, weight=1)

process_frame.grid_rowconfigure(0, weight=1)
process_frame.grid_columnconfigure(0, weight=1)

# Bucle principal
window.mainloop()