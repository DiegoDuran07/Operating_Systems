class Process:
    def __init__(self):
        self.name = None
        self.pid = None
        self.operation = None
        self.met = 0
        self.x = None
        self.y = None
        self.result = None
        self.fullOpe = None
        self.te = 0
        self.ttb = 0
        self.arrT = 0
        self.finT = 0
        self.servT = 0
        self.waitT = 0
        self.retT = 0
        self.resT = 0
        self.llegada = 0
        self.quantum = 0
        self.size = 0
